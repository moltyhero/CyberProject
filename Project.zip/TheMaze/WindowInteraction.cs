﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheMaze
{
    public static class WindowInteraction
    {
        public static MainWindow AppWindow;
        public static OnlineOptionsWindow onlineOptionsWindow;

    }
}
